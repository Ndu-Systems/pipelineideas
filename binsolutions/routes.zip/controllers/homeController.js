﻿app.controller('homeController', function ($http, $scope, $route, $window) {
});